# Advanced RAG modules
